<div class="fl-map">
	<iframe src="https://maps.google.com/maps?q=<?php echo urlencode($settings->address); ?>&iwloc=near&output=embed" width="100%" height="<?php echo $settings->height; ?>px" frameborder="0" style="border:0"></iframe>
</div>